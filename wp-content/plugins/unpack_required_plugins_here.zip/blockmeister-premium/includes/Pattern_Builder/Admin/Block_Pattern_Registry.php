<?php

namespace ProDevign\BlockMeister\Pattern_Builder\Admin;


use ProDevign\BlockMeister\BlockMeister;
use ProDevign\BlockMeister\Pattern_Builder\Pattern_Builder;
use ProDevign\BlockMeister\Utils;
use function ProDevign\BlockMeister\blockmeister_license;


class Block_Pattern_Registry {


	/**
	 * Post_Editor constructor.
	 *
	 */
	public function __construct() {
	}


	/**
	 * Initialize
	 */
	public function init() {

		if ( blockmeister_license()->is_plan_or_trial__premium_only( 'pro' ) ) {
			add_filter( 'should_load_remote_block_patterns', [ $this, 'should_load_remote_block_patterns_filter__premium_only' ] );
			$this->set_theme_support_for_core_block_patterns__premium_only();
		}

		add_action( 'admin_init', function () {
			global $pagenow;
			$post_id = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0;
			if ( Utils::is_blockmeister_pattern_list_table_screen() || ($post_id>0 && Utils::is_block_editor( $post_id ) ) || $pagenow === 'post-new.php' ) {
				if ( blockmeister_license()->is_plan_or_trial__premium_only( 'starter' ) ) {
					$this->load_remote_block_patterns__premium_only();
				}
				$this->register_custom_default_category_and_namespace();
				$this->register_custom_block_patterns();
				if ( blockmeister_license()->is_plan_or_trial__premium_only( 'starter' ) ) {
					$this->unregister_deactivated_block_patterns__premium_only();
				}
				if ( blockmeister_license()->is_plan_or_trial__premium_only( 'pro' ) ) {
					$this->maybe_unregister_all_block_patterns_registered_by_theme_or_active_plugins__premium_only();
				}
			}
		}, 1020 ); // needs to run after BlockMeister_Pattern_Category_Taxonomy->init()
	}

	/**
	 * Check if user choose in settings to opt opt-in of the themes support for registering local or remote core block patterns.
	 */
	public function set_theme_support_for_core_block_patterns__premium_only() {

		if ( ! blockmeister_license()->is_plan_or_trial( 'pro' ) ) { // if not on pro plan/trial or higher then do nothing
			return;
		}

		$has_already_theme_support_core_patterns      = get_theme_support( 'core-block-patterns' );
		$do_load_local_core_block_patterns            = (bool) get_option( 'blockmeister_load_local_core_block_patterns', true );
		$do_load_local_and_remote_core_block_patterns = (bool) get_option( 'blockmeister_load_local_and_remote_core_block_patterns', true );

		$is_theme_support_needed = $do_load_local_core_block_patterns || $do_load_local_and_remote_core_block_patterns;

		if ( ! $has_already_theme_support_core_patterns && $is_theme_support_needed ) {
			add_theme_support( 'core-block-patterns' );
		} else if ( $has_already_theme_support_core_patterns && ! $is_theme_support_needed ) {
			remove_theme_support( 'core-block-patterns' );
		}
	}

	/**
	 * Register Core's official patterns from wordpress.org/patterns.
	 * Note: the bulk of this code is taken from wp-includes/block-patterns.php, sans the current
	 * screen check because that blocks loading in our list table screen
	 */
	private function load_remote_block_patterns__premium_only() {

		$supports_core_patterns = get_theme_support( 'core-block-patterns' );

		/**
		 * Filter to disable remote block patterns.
		 *
		 * @param bool $should_load_remote
		 *
		 */
		$should_load_remote = apply_filters( 'should_load_remote_block_patterns', true );

		if ( $supports_core_patterns && $should_load_remote ) {

			$request         = new \WP_REST_Request( 'GET', '/wp/v2/pattern-directory/patterns' );
			$core_keyword_id = 11; // 11 is the ID for "core".
			$request->set_param( 'keyword', $core_keyword_id );
			$response = rest_do_request( $request );
			if ( $response->is_error() ) {
				return;
			}
			$patterns = $response->get_data();

			foreach ( $patterns as $settings ) {
				$pattern_name = 'core/' . sanitize_title( $settings['title'] );
				register_block_pattern( $pattern_name, (array) $settings );
			}
		}
	}

	/**
	 * The site name will act as the default category
	 * This overrides the core default of 'uncategorized'
	 */
	private function register_custom_default_category_and_namespace() {
		$site_name = get_bloginfo( 'name', 'display' ); // note: ia escaped by WP
		register_block_pattern_category( BlockMeister::get_default_block_namespace(), [ 'label' => $site_name ] );
	}

	/**
	 * Server side custom pattern registration.
	 *
	 * Security notes:
	 * - Escaping:      None of the registration args will be directly output to the screen.
	 *                  Therefore escaping isn't necessary at this point and will be done by WP when
	 *                  the patterns are rendered for preview or as rendered in a post/page.
	 * - Sanitization:  The registration args are sanitized to prevent unexpected results though.
	 */
	private function register_custom_block_patterns() {

		global $pagenow;

		$current_post_id = (int) isset( $_GET['post'] ) ? $_GET['post'] : - 1;

		// for use in the pattern list table we need to get posts of any status
		$is_blockmeister_pattern_list_table = $pagenow && $pagenow === 'edit.php' && isset( $_GET['post_type'] ) && $_GET['post_type'] === 'blockmeister_pattern';
		$post_status                        = $is_blockmeister_pattern_list_table ? 'any' : 'publish';

		$blockmeister_pattern_posts = get_posts( [
			'numberposts' => - 1, // get all
			'post_type'   => Pattern_Builder::POST_TYPE,
			'post_status' => $post_status,
		] );

		foreach ( $blockmeister_pattern_posts as $block_pattern ) {

			if ( $block_pattern->ID === $current_post_id ) {
				continue; // skip currently being edited pattern to prevent self nesting
			}

			$category_slugs     = wp_get_post_terms( $block_pattern->ID, 'pattern_category', [ 'fields' => 'id=>slug' ] );
			$pattern_categories = sizeof( $category_slugs ) > 0 ? explode( ",", implode( ",", $category_slugs ) ) : []; // explode/implode re-indexes array

			$keyword_names    = wp_get_post_terms( $block_pattern->ID, 'pattern_keyword', [ 'fields' => 'names' ] );
			$pattern_keywords = sizeof( $keyword_names ) > 0 ? explode( ",", implode( ",", $keyword_names ) ) : []; // explode/implode re-indexes array

			$filtered_post_content = wp_kses_post( $block_pattern->post_content );
			if ( $filtered_post_content !== $block_pattern->post_content ) { // some content was stripped out by kses method
				if ( current_user_can( 'unfiltered_html' ) ) {
					$filtered_post_content = $block_pattern->post_content; // potential unsafe content is the responsibility of user
				}
			}

			$pattern_props = [
				'title'         => strip_tags( $block_pattern->post_title ),
				'description'   => strip_tags( $block_pattern->post_excerpt ),
				'content'       => $filtered_post_content,
				'categories'    => array_map( 'strip_tags', $pattern_categories ),
				'keywords'      => array_map( 'strip_tags', $pattern_keywords ),
				'viewportWidth' => (int) get_post_meta( $block_pattern->ID, "_bm_viewport_width", true ),
			];

			$block_namespace    = BlockMeister::get_default_block_namespace();
			$block_pattern_name = sanitize_key( $block_pattern->post_name );
			$pattern_name       = "{$block_namespace}/{$block_pattern_name}";
			register_block_pattern( $pattern_name, $pattern_props );
		}

	}

	/**
	 * Unless this request is for the pattern list table, unregister all deactivated patterns;
	 */
	public function unregister_deactivated_block_patterns__premium_only() {
		global $parent_file;

		// We need all active and inactive patterns to show in the pattern list table
		if ( 'edit.php?post_type=blockmeister_pattern' === $parent_file ) {
			return; // don't unregister
		}

		$wp_block_pattern_registry = \WP_Block_Patterns_Registry::get_instance();
		$inactive_patterns         = get_option( 'blockmeister_inactive_patterns', [] );
		foreach ( $inactive_patterns as $inactive_pattern ) {
			if ( $wp_block_pattern_registry->is_registered( $inactive_pattern ) ) {
				unregister_block_pattern( $inactive_pattern );
			}
		}
	}

	public function maybe_unregister_all_block_patterns_registered_by_theme_or_active_plugins__premium_only() {

		if ( ! blockmeister_license()->is_plan_or_trial( 'pro' ) ) { // if not on pro plan/trial or higher then do nothing
			return;
		}

		$do_load_local_theme_and_plugin_block_patterns_setting = (bool) get_option( 'blockmeister_load_local_theme_and_plugin_block_patterns', true );

		if ( $do_load_local_theme_and_plugin_block_patterns_setting ) {
			return;
		}

		$custom_namespace          = BlockMeister::get_default_block_namespace();
		$wp_block_pattern_registry = \WP_Block_Patterns_Registry::get_instance();
		$registered_block_patterns = $wp_block_pattern_registry->get_all_registered();
		foreach ( $registered_block_patterns as $registered_block_pattern ) {
			$pattern_namespace         = strtok( $registered_block_pattern['name'], '/' );
			$is_custom_namespace       = $pattern_namespace == $custom_namespace;
			$is_core_namespace         = $pattern_namespace === 'core';
			$is_theme_plugin_namespace = ! $is_custom_namespace && ! $is_core_namespace;
			if ( $is_theme_plugin_namespace ) { // then unregister (as requested via user setting)
				unregister_block_pattern( $registered_block_pattern['name'] );
			}
		}
	}

	/**
	 * Filter to enable/disable loading of remote core block patterns.
	 * Uses 'blockmeister_load_remote_core_block_patterns' setting.
	 *
	 * Note: filter is only hooked in init() for pro plan or higher
	 *
	 * @return bool
	 */
	public function should_load_remote_block_patterns_filter__premium_only( $should_load ) {
		$do_load_remote_core_block_patterns = (bool) get_option( 'blockmeister_load_local_and_remote_core_block_patterns', true );
		return $do_load_remote_core_block_patterns;
	}


}

